---
layout: home
author_profile: true
---

Bem-vindo à minha página acadêmica. Sou Marçal Evangelista Santana, pesquisador na área de astrofísica de pequenos corpos — cometas, asteroides e detritos do Sistema Solar.

Neste espaço você encontrará minhas [publicações](/publicacoes/), [projetos](/projetos/), e códigos disponíveis no [GitHub](/codigo/).