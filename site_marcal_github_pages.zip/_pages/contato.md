---
title: "Contato"
layout: single
permalink: /contato/
author_profile: true
---

Entre em contato:

- **Email**: seu.email@exemplo.com
- **ORCID**: [0000-0002-1153-8768](https://orcid.org/0000-0002-1153-8768)
- **Lattes**: [9028132638049706](https://lattes.cnpq.br/9028132638049706)
- **GitHub**: [@marcalevangelista](https://github.com/marcalevangelista)