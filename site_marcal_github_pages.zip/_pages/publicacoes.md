---
title: "Publicações"
layout: single
permalink: /publicacoes/
author_profile: true
---

### Lista de publicações

Você pode consultar minhas publicações diretamente em:

- [ORCID](https://orcid.org/0000-0002-1153-8768)
- [Lattes](https://lattes.cnpq.br/9028132638049706)
- [NASA/ADS](https://ui.adsabs.harvard.edu/search/q=author%3A%22Evangelista%2C%20M.%22&sort=date%20desc)

Futuramente adicionarei uma lista automática com BibTeX.