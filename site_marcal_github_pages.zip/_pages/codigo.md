---
title: "Código"
layout: single
permalink: /codigo/
author_profile: true
---

### Repositórios no GitHub

Veja meus códigos no [GitHub](https://github.com/marcalevangelista):

- `pedra`: Pipeline para análise de pequenos corpos
- `comet-dust-models`: Simulações de poeira cometária

Mais scripts e utilitários serão adicionados conforme o projeto avança.