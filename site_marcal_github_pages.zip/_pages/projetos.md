---
title: "Projetos"
layout: single
permalink: /projetos/
author_profile: true
---

### Projetos em andamento

- Sob Este Céu — divulgação científica no sertão cearense
- Fotometria de cometas ativos com filtros SDSS
- Modelagem de poeira cometária (Mie, Henyey-Greenstein)

Mais em breve!